class ReviewerAgent:
    """简单代码审查"""
    def review_code(self, code: str):
        if "return" in code:
            return "代码逻辑简单，未发现明显 bug"
        return "需要进一步检查"
