class PlannerAgent:
    """负责拆解任务"""
    def plan_task(self, requirement: str):
        tasks = [
            "实现用户注册功能",
            "实现用户登录功能",
            "实现密码修改功能"
        ]
        return tasks
