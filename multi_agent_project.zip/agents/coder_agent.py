class CoderAgent:
    """生成任务代码"""
    def write_code(self, task: str):
        if "注册" in task:
            return """def register_user(username, password):
    # 简单示例
    return {"username": username, "status": "registered"}"""
        elif "登录" in task:
            return """def login_user(username, password):
    # 简单示例
    return {"username": username, "status": "logged_in"}"""
        elif "密码修改" in task:
            return """def change_password(username, new_password):
    # 简单示例
    return {"username": username, "status": "password_changed"}"""
        else:
            return "# 未知任务"
