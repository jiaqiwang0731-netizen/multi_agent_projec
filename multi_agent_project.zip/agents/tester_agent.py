class TesterAgent:
    """简单测试"""
    def test_code(self, code: str):
        return "测试通过"
