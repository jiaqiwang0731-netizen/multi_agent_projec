from agents.planner_agent import PlannerAgent
from agents.coder_agent import CoderAgent
from agents.reviewer_agent import ReviewerAgent
from agents.tester_agent import TesterAgent

def multi_agent_workflow(requirement: str):
    planner = PlannerAgent()
    coder = CoderAgent()
    reviewer = ReviewerAgent()
    tester = TesterAgent()

    tasks = planner.plan_task(requirement)
    print("拆分任务:", tasks)

    results = []
    for task in tasks:
        code = coder.write_code(task)
        review = reviewer.review_code(code)
        test = tester.test_code(code)
        results.append({
            "task": task,
            "code": code,
            "review": review,
            "test": test
        })
        print(f"\n任务: {task}")
        print("代码:", code)
        print("审查:", review)
        print("测试:", test)

    return results

if __name__ == "__main__":
    requirement = "实现一个简单的用户管理系统"
    multi_agent_workflow(requirement)
